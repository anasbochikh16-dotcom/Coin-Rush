# Coin Rush 7.0 — Play Store Release Preparation

تم تجهيز المشروع ليكون أساس إصدار Google Play.

## ما تم تجهيزه
- versionCode = 7
- versionName = 7.0.0
- BuildConfig يحتوي معرفات إعلانات اختبارية فقط.
- تعليمات دمج AdMob موجودة في `ADMOB_SETUP.md`.
- المشروع مهيأ لإخراج Android App Bundle (AAB).

## مهم
لا توجد مفاتيح AdMob حقيقية داخل المشروع. عند إنشاء حساب AdMob، استبدل معرفات الاختبار بمعرفاتك في المكان المناسب، واستخدم معرفات الاختبار أثناء التطوير.

## إنشاء AAB
في Android Studio:
1. افتح المشروع.
2. Gradle Sync.
3. Build > Generate Signed Bundle / APK.
4. اختر Android App Bundle.
5. أنشئ أو اختر Keystore.
6. اختر release.
7. ابنِ ملف `.aab`.

ملف AAB الناتج هو الذي ترفعه إلى Google Play Console.

## النشر
ستحتاج إلى حساب Google Play Console، بيانات المتجر، سياسة خصوصية مناسبة، لقطات شاشة، واختبار الإصدار قبل الإطلاق وفق متطلبات Google الحالية.
