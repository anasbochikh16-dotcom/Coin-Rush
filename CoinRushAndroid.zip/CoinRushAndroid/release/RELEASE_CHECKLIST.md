# Release checklist

- [ ] Test game on a real Android phone
- [ ] Replace test ad IDs only after AdMob setup
- [ ] Add final app icon and screenshots
- [ ] Complete privacy policy
- [ ] Create signing keystore and store it safely
- [ ] Generate signed AAB
- [ ] Upload AAB to Play Console
- [ ] Complete Play Console content/data-safety forms
- [ ] Run required testing track
- [ ] Submit for review
