# Coin Rush — Privacy Policy Starter

This is a starter template, not legal advice.

Coin Rush may store gameplay progress locally on the device, such as score, coins, achievements, settings, and daily progress.

If advertising or analytics SDKs are added, this policy must be updated to accurately describe the data collected by those services, their purposes, and the choices available to users.

Contact: [ضع بريدك الإلكتروني هنا]

Last updated: [ضع التاريخ هنا]
