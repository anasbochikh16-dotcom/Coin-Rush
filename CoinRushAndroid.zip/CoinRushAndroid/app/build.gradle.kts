plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    buildFeatures {
        buildConfig = true
    }
    namespace = "com.example.coinrush"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.coinrush"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "7.0.0"
        buildConfigField("String", "ADMOB_BANNER_ID", ""ca-app-pub-3940256099942544/6300978111"")
        buildConfigField("String", "ADMOB_INTERSTITIAL_ID", ""ca-app-pub-3940256099942544/1033173712"")
    }
}
