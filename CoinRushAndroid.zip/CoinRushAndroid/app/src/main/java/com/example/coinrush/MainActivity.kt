package com.example.coinrush

import android.app.*
import android.os.*
import android.content.*
import android.graphics.*
import android.media.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var frame: FrameLayout
    private var soundPool: SoundPool? = null
    private val sounds = mutableMapOf<String,Int>()
    private var soundOn=true
    private var wallet=0; private var best=0; private var lifetime=0; private var skin=0
    private var dailyDate=""; private var dailyProgress=0; private var dailyClaimed=false
    private var timer: CountDownTimer?=null
    private var score=0; private var roundCoins=0; private var combo=0; private var hearts=3
    private val costs=intArrayOf(0,50,120)
    private val names=arrayOf("ذهبي","أزرق","بنفسجي")

    override fun onCreate(b:Bundle?){super.onCreate(b); prefs=getSharedPreferences("coinrush",0); load(); setupSound(); home()}
    private fun load(){
        wallet=prefs.getInt("wallet",0); best=prefs.getInt("best",0); lifetime=prefs.getInt("lifetime",0); skin=prefs.getInt("skin",0)
        soundOn=prefs.getBoolean("sound",true); dailyDate=prefs.getString("date","")?:""
        dailyProgress=prefs.getInt("daily",0); dailyClaimed=prefs.getBoolean("claimed",false); daily()
    }
    private fun save(){prefs.edit().putInt("wallet",wallet).putInt("best",best).putInt("lifetime",lifetime).putInt("skin",skin).putBoolean("sound",soundOn).putString("date",dailyDate).putInt("daily",dailyProgress).putBoolean("claimed",dailyClaimed).apply()}
    private fun daily(){
        val d=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
        if(dailyDate!=d){dailyDate=d;dailyProgress=0;dailyClaimed=false;save()}
    }
    private fun setupSound(){
        val a=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        soundPool=SoundPool.Builder().setMaxStreams(5).setAudioAttributes(a).build()
        listOf("coin","wrong","buy","gameover").forEach{val id=resources.getIdentifier(it,"raw",packageName);if(id!=0)sounds[it]=soundPool!!.load(this,id,1)}
    }
    private fun s(n:String){if(soundOn)sounds[n]?.let{soundPool?.play(it,1f,1f,1,0,1f)}}
    private fun layout():LinearLayout{
        frame=FrameLayout(this);frame.setBackgroundColor(Color.rgb(12,18,32));setContentView(frame)
        val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(28,28,28,28);frame.addView(l,FrameLayout.LayoutParams(-1,-1));return l
    }
    private fun title(t:String)=TextView(this).apply{text=t;textSize=30f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,10,0,18)}
    private fun btn(t:String,a:()->Unit)=Button(this).apply{text=t;textSize=17f;setOnClickListener{a()};layoutParams=LinearLayout.LayoutParams(-1,58).apply{setMargins(0,5,0,5)}}
    private fun home(){
        daily();val l=layout();l.addView(title("🪙 COIN RUSH 6.0"))
        l.addView(TextView(this).apply{text="الرصيد: $wallet 🪙   |   أفضل نتيجة: $best";textSize=18f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,0,0,12)})
        l.addView(TextView(this).apply{text=if(dailyClaimed)"🎁 المهمة اليومية مكتملة" else "🎯 المهمة اليومية: $dailyProgress/15 عملة";textSize=16f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,0,0,8)})
        l.addView(btn("▶ ابدأ اللعب"){start()});l.addView(btn("🛒 المتجر"){shop()});l.addView(btn("🏆 الإنجازات"){achievements()});l.addView(btn("⚙ الإعدادات"){settings()})
    }
    private fun start(){
        score=0;roundCoins=0;combo=0;hearts=3
        frame=FrameLayout(this);frame.setBackgroundColor(Color.rgb(8,13,24));setContentView(frame)
        val hud=TextView(this).apply{textSize=18f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(10,18,10,10)}
        frame.addView(hud,FrameLayout.LayoutParams(-1,75))
        val gv=GameView(this);frame.addView(gv,FrameLayout.LayoutParams(-1,-1))
        timer=object:CountDownTimer(30000,1000){
            override fun onTick(ms:Long){hud.text="النقاط $score   🪙 $roundCoins   ❤️ $hearts   🔥 x${maxOf(1,combo)}   ⏱ ${ms/1000}"}
            override fun onFinish(){end("انتهى الوقت")}
        }.start()
    }
    private fun end(reason:String){
        timer?.cancel();timer=null
        wallet+=score/10+roundCoins;if(score>best)best=score;save();s("gameover");result(reason)
    }
    private fun result(reason:String){
        val l=layout();l.addView(title("🏁 النتيجة"))
        l.addView(TextView(this).apply{text="$reason\n\nنتيجتك: $score\nأفضل نتيجة: $best\nعملات الجولة: $roundCoins";textSize=21f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,10,0,20)})
        l.addView(btn("🔄 إعادة اللعب"){start()});l.addView(btn("🏠 الرئيسية"){home()})
    }
    private fun achievements(){
        val l=layout();l.addView(title("🏆 الإنجازات"))
        val a=listOf("first" to "أكمل أول جولة — +20 🪙","combo5" to "وصل إلى x5 — +30 🪙","score300" to "حقق 300 نقطة — +50 🪙","collector50" to "اجمع 50 عملة — +100 🪙")
        a.forEach{(k,d)->l.addView(TextView(this).apply{text=(if(prefs.getBoolean("ach_$k",false))"✅ " else "🔒 ")+d;textSize=17f;setTextColor(Color.WHITE);setPadding(10,12,10,12)})}
        l.addView(btn("🏠 رجوع"){home()})
    }
    private fun shop(){
        val l=layout();l.addView(title("🛒 المتجر"));l.addView(TextView(this).apply{text="رصيدك: $wallet 🪙";textSize=19f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,0,0,10)})
        names.indices.forEach{i->l.addView(btn("🎨 ${names[i]} — "+when{skin==i->"مستخدم";prefs.getBoolean("owned$i",i==0)->"اختيار";else->"${costs[i]} 🪙"}){
            if(prefs.getBoolean("owned$i",i==0)){skin=i;save();shop()}
            else if(wallet>=costs[i]){wallet-=costs[i];prefs.edit().putBoolean("owned$i",true).apply();skin=i;save();s("buy");shop()}
            else Toast.makeText(this,"العملات غير كافية",Toast.LENGTH_SHORT).show()
        })})
        l.addView(btn("🏠 رجوع"){home()})
    }
    private fun settings(){
        val l=layout();l.addView(title("⚙ الإعدادات"));l.addView(btn(if(soundOn)"🔊 الصوت: تشغيل" else "🔇 الصوت: إيقاف"){soundOn=!soundOn;save();settings()})
        l.addView(TextView(this).apply{text="الإعلانات جاهزة للإضافة في مرحلة النشر عبر AdMob. لا توجد مفاتيح حقيقية داخل المشروع.";textSize=15f;setTextColor(Color.LTGRAY);setPadding(10,20,10,20)})
        l.addView(btn("🏠 رجوع"){home()})
    }
    private fun unlock(k:String,reward:Int){if(!prefs.getBoolean("ach_$k",false)){prefs.edit().putBoolean("ach_$k",true).apply();wallet+=reward;save()}}
    inner class GameView(c:Context):View(c){
        val p=Paint(1);var x=200f;var y=400f;var r=48f;val rnd=Random()
        init{post{move()}}
        fun move(){r=(52-(score/100)*2).coerceAtLeast(30).toFloat();x=r+rnd.nextFloat()*(width-2*r).coerceAtLeast(1f);y=100+r+rnd.nextFloat()*(height-130-2*r).coerceAtLeast(1f);invalidate()}
        override fun onDraw(c:Canvas){p.color=when(skin){1->Color.rgb(55,150,255);2->Color.rgb(180,80,255);else->Color.rgb(255,193,7)};c.drawCircle(x,y,r,p);p.color=Color.WHITE;p.textAlign=Paint.Align.CENTER;p.textSize=26f;c.drawText("🪙",x,y+9,p)}
        override fun onTouchEvent(e:MotionEvent):Boolean{
            if(e.action!=MotionEvent.ACTION_DOWN)return true
            val dx=e.x-x;val dy=e.y-y
            if(dx*dx+dy*dy<=r*r){
                combo++;val mult=1+combo/5;score+=10*mult;roundCoins++;lifetime++;dailyProgress=minOf(15,dailyProgress+1)
                if(dailyProgress>=15&&!dailyClaimed){dailyClaimed=true;wallet+=25;Toast.makeText(this@MainActivity,"🎁 المهمة اليومية! +25 🪙",Toast.LENGTH_SHORT).show()}
                if(combo>=5)unlock("combo5",30);if(score>=300)unlock("score300",50);if(lifetime>=50)unlock("collector50",100)
                save();s("coin");move()
            }else{combo=0;hearts--;s("wrong");if(hearts<=0)end("نفدت القلوب")}
            return true
        }
    }
    override fun onDestroy(){timer?.cancel();soundPool?.release();super.onDestroy()}
}
